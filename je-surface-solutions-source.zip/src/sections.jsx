import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import {
  ArrowUpRight,
  ArrowDown,
  Phone,
  Mail,
  MapPin,
  Menu,
  X,
  Home,
  Trees,
  Layers,
  Droplets,
  PaintRoller,
  Paintbrush,
  Fence,
  ShieldCheck,
  Sun,
  Mountain,
  Upload,
  CheckCircle2,
  Trash2,
  ClipboardCheck,
  Lock,
} from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

/* ----------------------------------------------------------------
   Business info — swap placeholders for real details
---------------------------------------------------------------- */
const BRAND = {
  name: 'J&E Surface Solutions',
  short: 'J&E',
  tagline: 'Cabin re-staining & wood protection',
  phoneDisplay: '(435) 691-1213',
  phoneTel: '+14356911213',
  email: 'je.surfacesolutions@gmail.com',
  region: 'Southern Utah',
  base: 'Cedar City, UT',
  hours: 'Mon–Sat · 7am–6pm',
  owners: 'Caden Jacobs & Colton Emmett',
  radius: '100 miles of Cedar City',
}

const SERVICE_AREAS = [
  'Duck Creek Village',
  'Brian Head',
  'Elk Ridge',
  'Eagle Point',
  'Cedar Mountain',
  'Panguitch Lake',
  'Pine Valley',
  'Kolob',
  'Navajo Lake',
  'Mammoth Creek',
]

export const NAV_LINKS = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Services', to: '/services' },
  { label: 'Process', to: '/process' },
  { label: 'Service area', to: '/service-area' },
  { label: 'Contact', to: '/contact' },
]

const SERVICES = [
  {
    icon: Home,
    title: 'Cabin & log home re-staining',
    text: 'Full-exterior re-stains for log and sided cabins. Two coats minimum, and a third when the wood needs it.',
  },
  {
    icon: Trees,
    title: 'Sand blasting',
    text: 'For badly weathered logs, sand blasting strips old, failing finish and grey wood back to fresh, sound wood.',
  },
  {
    icon: Layers,
    title: 'Deck & railing staining',
    text: 'Decks take the hardest beating up high. We prep and stain boards, rails, and stairs to stand up to sun and snow.',
  },
  {
    icon: Droplets,
    title: 'Power washing & sanding',
    text: 'Every surface gets the prep it actually needs, from a wash to a full sand, so new stain bonds instead of peeling.',
  },
  {
    icon: PaintRoller,
    title: 'Sprayed or hand-rolled',
    text: 'Sprayed for speed and even coverage. Hand-rolled wherever overspray would be a problem, like near cars, neighbors, or stonework.',
  },
  {
    icon: ShieldCheck,
    title: 'Full masking & cleanup',
    text: 'AC units, windows, doors, and fixtures are masked before any stain goes on, and everything comes off clean at the end.',
  },
]

const IMG = {
  hero: 'https://images.unsplash.com/photo-1542718610-a1d656d1884c?auto=format&fit=crop&w=2000&q=80',
  step1: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?auto=format&fit=crop&w=1200&q=80',
  step2: 'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=80',
  step3: 'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=80',
  step4: 'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?auto=format&fit=crop&w=1200&q=80',
  area: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1400&q=80',
}

/* ----------------------------------------------------------------
   Logo lockup — roofline + J&E, mirrors the brand mark
---------------------------------------------------------------- */
export function LogoMark({ light = false, className = '' }) {
  const color = light ? '#F6F1EA' : '#1C1714'
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden="true">
        <path d="M4 17 L20 5 L36 17" fill="none" stroke="#C8642E" strokeWidth="3.2" strokeLinejoin="miter" />
        <text
          x="20"
          y="34"
          textAnchor="middle"
          fontFamily="Plus Jakarta Sans, sans-serif"
          fontWeight="800"
          fontSize="15"
          fill={color}
        >
          J&amp;E
        </text>
      </svg>
      <span className={`leading-[1.15] font-display font-bold text-[11px] uppercase tracking-[0.16em] ${light ? 'text-white' : 'text-ink'}`}>
        <span className="block">Surface</span>
        <span className="block">Solutions</span>
      </span>
    </span>
  )
}

/* ----------------------------------------------------------------
   1. Navbar
---------------------------------------------------------------- */
export function Navbar() {
  const [scrolledPast, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  // Pages without a dark hero at the top get the solid header right away
  const scrolled = scrolledPast || ['/privacy', '/terms'].includes(pathname)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
  }, [open])

  useEffect(() => setOpen(false), [pathname])

  return (
    <>
      <header
        className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-5xl rounded-full px-4 sm:px-6 py-2.5 transition-all duration-500 ${
          scrolled ? 'glass shadow-lg shadow-deep/5' : 'bg-transparent border border-white/10'
        }`}
      >
        <nav className="flex items-center justify-between gap-4">
          <Link to="/" aria-label="J&E Surface Solutions home">
            <LogoMark light={!scrolled} />
          </Link>
          <ul className="hidden lg:flex items-center gap-7">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <NavLink
                  to={l.to}
                  end
                  className={({ isActive }) =>
                    `lift-on-hover relative inline-block text-sm font-medium transition-colors after:absolute after:left-0 after:-bottom-1 after:h-px after:bg-accent after:transition-all ${
                      isActive ? 'after:w-full' : 'after:w-0'
                    } ${
                      scrolled
                        ? isActive ? 'text-ink' : 'text-ink/70 hover:text-primary-dark'
                        : isActive ? 'text-white' : 'text-white/75 hover:text-white'
                    }`
                  }
                >
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-2">
            <Link
              to="/contact"
              className="magnetic-btn hidden sm:inline-flex items-center gap-2 bg-accent text-white px-5 py-2.5 rounded-full text-sm font-semibold shadow-lg shadow-accent/30"
            >
              Free estimate <ArrowUpRight className="h-4 w-4" strokeWidth={2.4} />
            </Link>
            <button
              onClick={() => setOpen(true)}
              className={`lg:hidden h-10 w-10 inline-flex items-center justify-center rounded-full ${
                scrolled ? 'text-ink bg-ink/5' : 'text-white bg-white/10'
              }`}
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 z-[60] bg-deep/90 backdrop-blur-2xl transition-all duration-500 lg:hidden ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className={`flex flex-col h-full px-6 pt-6 pb-10 transition-transform duration-500 ${open ? 'translate-y-0' : '-translate-y-6'}`}>
          <div className="flex items-center justify-between">
            <LogoMark light />
            <button
              onClick={() => setOpen(false)}
              className="h-10 w-10 inline-flex items-center justify-center rounded-full bg-white/10 text-white"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <ul className="mt-16 space-y-6">
            {NAV_LINKS.map((l, i) => (
              <li key={l.to}>
                <NavLink
                  to={l.to}
                  end
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `flex items-baseline gap-4 font-display font-bold text-4xl tracking-tight ${isActive ? 'text-primary-light' : 'text-white'}`
                  }
                >
                  <span className="font-mono text-xs text-primary-light">0{i + 1}</span>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className="mt-auto space-y-3">
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="flex items-center justify-center gap-2 bg-accent text-white px-6 py-4 rounded-full font-semibold"
            >
              Get a free estimate <ArrowUpRight className="h-4 w-4" />
            </Link>
            <a
              href={`tel:${BRAND.phoneTel}`}
              className="flex items-center justify-center gap-2 border border-white/15 text-white px-6 py-4 rounded-full font-semibold"
            >
              <Phone className="h-4 w-4" /> {BRAND.phoneDisplay}
            </a>
          </div>
        </div>
      </div>
    </>
  )
}

/* ----------------------------------------------------------------
   2. Hero
---------------------------------------------------------------- */
export function Hero() {
  const ref = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.hero-line-1', { y: 40, opacity: 0, duration: 1, delay: 0.3, ease: 'power3.out' })
      gsap.from('.hero-line-2', { y: 60, opacity: 0, duration: 1.2, delay: 0.5, ease: 'power3.out' })
      gsap.from('.hero-cta, .hero-meta', { y: 24, opacity: 0, duration: 0.8, delay: 0.8, stagger: 0.12, ease: 'power3.out' })
    }, ref)
    return () => ctx.revert()
  }, [])

  // Floating pine needles / wood flecks in top-right
  const flecks = [
    { top: '18%', right: '12%', size: 10, delay: '0s', color: '#C8642E' },
    { top: '26%', right: '22%', size: 6, delay: '1.2s', color: '#C49A6C' },
    { top: '12%', right: '30%', size: 8, delay: '2.1s', color: '#F6F1EA' },
    { top: '34%', right: '8%', size: 7, delay: '0.6s', color: '#C49A6C' },
    { top: '22%', right: '40%', size: 5, delay: '3s', color: '#C8642E' },
  ]

  return (
    <section id="home" ref={ref} className="relative min-h-[100dvh] overflow-hidden bg-deep">
      <img
        src={IMG.hero}
        alt="Wood cabin at sunset among mountain pines"
        className="absolute inset-0 h-full w-full object-cover brightness-[0.6]"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-deep/85 via-deep/35 to-deep/60" />
      <div className="absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-deep to-transparent" />

      <div className="absolute inset-0 hidden sm:block pointer-events-none">
        {flecks.map((f, i) => (
          <span
            key={i}
            className="absolute animate-float rounded-full opacity-70"
            style={{
              top: f.top,
              right: f.right,
              width: f.size,
              height: f.size * 2.4,
              background: f.color,
              borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
              animationDelay: f.delay,
              transform: `rotate(${i * 23}deg)`,
            }}
          />
        ))}
      </div>

      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-32 pb-24 min-h-[100dvh] flex flex-col justify-end">
        <p className="hero-meta inline-flex items-center gap-2 font-mono text-[10px] sm:text-xs uppercase tracking-[0.25em] text-white/70 mb-6">
          <Mountain className="h-3.5 w-3.5 text-accent" /> Mountain cabin specialists · {BRAND.region}
        </p>
        <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl font-bold text-white tracking-tighter leading-[0.95] max-w-5xl">
          <span className="hero-line-1 block">Protect the cabin</span>
          <span className="hero-line-2 block font-serif italic font-normal tracking-[-0.01em] text-primary-light text-balance">
            that the mountains wear down.
          </span>
        </h1>
        <p className="hero-meta mt-8 max-w-xl text-white/75 text-base sm:text-lg leading-relaxed">
          High-altitude sun, snow, and freeze-thaw cycles strip wood fast. We re-stain and seal cabins,
          log homes, and decks across Southern Utah so they stay beautiful and stay dry, year after year.
        </p>
        <div className="hero-cta mt-10 flex flex-wrap gap-3">
          <Link
            to="/contact"
            className="magnetic-btn inline-flex items-center gap-2 bg-accent text-white px-6 py-3.5 rounded-full font-semibold shadow-lg shadow-accent/30"
          >
            Get a free estimate <ArrowUpRight className="h-4 w-4" strokeWidth={2.4} />
          </Link>
          <a
            href={`tel:${BRAND.phoneTel}`}
            className="magnetic-btn inline-flex items-center gap-2 glass-dark text-white px-6 py-3.5 rounded-full font-semibold border border-white/15"
          >
            <Phone className="h-4 w-4" /> {BRAND.phoneDisplay}
          </a>
        </div>
        <div className="hero-meta mt-14 flex flex-wrap gap-x-8 gap-y-3 font-mono text-[10px] sm:text-[11px] uppercase tracking-[0.18em] text-white/55">
          <span className="inline-flex items-center gap-2"><Paintbrush className="h-3.5 w-3.5" /> 2–3 coats every job</span>
          <span className="inline-flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Sand blasting & sanding</span>
          <span className="inline-flex items-center gap-2"><MapPin className="h-3.5 w-3.5" /> Within {BRAND.radius}</span>
        </div>
      </div>

      <a
        href="#intro"
        className="absolute bottom-8 right-6 sm:right-10 lg:right-16 z-10 hidden sm:flex flex-col items-center gap-3 text-white/50"
        aria-label="Scroll down"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] [writing-mode:vertical-rl]">Scroll</span>
        <span className="relative h-14 w-px bg-white/20 overflow-hidden">
          <span className="absolute inset-x-0 top-0 h-5 bg-accent animate-[float_2s_ease-in-out_infinite]" />
        </span>
      </a>
    </section>
  )
}

/* ----------------------------------------------------------------
   3a. Cabin condition shuffler
---------------------------------------------------------------- */
function ConditionShuffler() {
  const items = [
    { tag: 'Log cabin', label: 'South wall · Brian Head', meta: '9,800 ft', health: 8 },
    { tag: 'Deck', label: 'Wraparound deck · Duck Creek', meta: '8,400 ft', health: 12 },
    { tag: 'Siding', label: 'Cedar siding · Pine Valley', meta: '6,800 ft', health: 17 },
  ]
  const [stack, setStack] = useState(items)

  useEffect(() => {
    const interval = setInterval(() => {
      setStack((prev) => {
        const next = [...prev]
        next.unshift(next.pop())
        return next
      })
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative h-44 w-full">
      {stack.map((item, i) => (
        <div
          key={item.tag}
          style={{
            transform: `translate(${i * 14}px, ${i * 14}px) scale(${1 - i * 0.05})`,
            zIndex: stack.length - i,
            opacity: 1 - i * 0.25,
            transition: 'transform 0.7s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.6s ease',
          }}
          className="absolute inset-0 bg-surface border border-divider rounded-3xl p-5 shadow-md"
        >
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-widest text-primary-dark bg-primary/10 px-2 py-1 rounded-full">
              {item.tag}
            </span>
            <span className="font-mono text-xs text-muted">{item.meta}</span>
          </div>
          <div className="mt-4 font-display text-lg font-semibold text-ink leading-tight">{item.label}</div>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {Array.from({ length: 20 }).map((_, idx) => (
                <span
                  key={idx}
                  className="h-1 w-1 rounded-full"
                  style={{ background: idx < item.health ? '#C8642E' : '#E4DACD' }}
                />
              ))}
            </div>
            <span className="font-mono text-[9px] uppercase tracking-widest text-muted">Finish left</span>
          </div>
        </div>
      ))}
    </div>
  )
}

/* ----------------------------------------------------------------
   3b. Signature animation — stain dripping onto a wood plank
---------------------------------------------------------------- */
function StainDrip() {
  const [statusIdx, setStatusIdx] = useState(0)
  const [count, setCount] = useState(3)

  const statuses = [
    { text: 'UV index 9 · finish fading', label: 'Exposed', tone: 'accent' },
    { text: 'Grain greying · re-stain due', label: 'Due', tone: 'accent' },
    { text: 'Crew on site · coat 2 of 3', label: 'Staining', tone: 'primary' },
    { text: 'Sealed · ready for winter', label: 'Protected', tone: 'emerald' },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setStatusIdx((idx) => {
        const next = (idx + 1) % statuses.length
        if (next === statuses.length - 1) setCount((c) => c + 1)
        return next
      })
    }, 2300)
    return () => clearInterval(interval)
  }, [])

  const drops = [
    { left: '15%', delay: '0.0s', dur: '2.6s', size: 14 },
    { left: '26%', delay: '1.3s', dur: '3.0s', size: 11 },
    { left: '38%', delay: '0.6s', dur: '2.8s', size: 16 },
    { left: '50%', delay: '1.8s', dur: '2.4s', size: 12 },
    { left: '62%', delay: '0.9s', dur: '3.1s', size: 15 },
    { left: '74%', delay: '2.0s', dur: '2.7s', size: 11 },
    { left: '85%', delay: '0.4s', dur: '2.9s', size: 14 },
  ]
  const soaks = [
    { left: '22%', delay: '0.2s' },
    { left: '48%', delay: '1.0s' },
    { left: '76%', delay: '1.8s' },
  ]

  const status = statuses[statusIdx]
  const toneText =
    status.tone === 'emerald' ? 'text-emerald-700' : status.tone === 'accent' ? 'text-accent-dark' : 'text-primary-dark'
  const toneDot = status.tone === 'emerald' ? 'bg-emerald-600' : status.tone === 'accent' ? 'bg-accent' : 'bg-primary'

  return (
    <div
      className="relative h-44 w-full rounded-3xl overflow-hidden border border-primary/15"
      style={{ background: 'linear-gradient(180deg, #FBF5EC 0%, #F2E4CF 70%, #E8D2B2 100%)' }}
    >
      <div className="absolute -top-8 -left-6 h-20 w-32 rounded-full bg-white/60 blur-2xl" />
      <div className="absolute top-2 right-10 h-14 w-24 rounded-full bg-white/50 blur-xl" />

      {/* Header */}
      <div className="absolute top-3 left-4 right-4 flex items-center justify-between z-20">
        <div className="flex items-center gap-2">
          <PaintRoller className="h-3.5 w-3.5 text-primary-dark" strokeWidth={2.2} />
          <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary-dark">Stain cycle</span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="font-display font-bold text-sm text-ink tabular-nums">{String(count).padStart(2, '0')}</span>
          <span className="font-mono text-[9px] uppercase tracking-widest text-muted">sealed</span>
        </div>
      </div>

      {/* Brush bristle bar (source) */}
      <svg className="absolute left-3 right-3 top-9 h-5" viewBox="0 0 400 20" preserveAspectRatio="none">
        <rect x="0" y="2" width="400" height="7" rx="3" fill="#6B4220" fillOpacity="0.85" />
        <rect x="0" y="3" width="400" height="1.5" fill="#C49A6C" fillOpacity="0.6" />
        {Array.from({ length: 50 }).map((_, i) => (
          <rect key={i} x={i * 8 + 2} y="9" width="3" height={6 + (i % 3) * 2} rx="1.5" fill="#8B5A2B" fillOpacity="0.55" />
        ))}
      </svg>

      {/* Stain drop field */}
      <div className="absolute inset-x-0 top-14 bottom-11 overflow-hidden">
        {drops.map((d, i) => (
          <svg
            key={i}
            className="absolute top-0"
            style={{
              left: d.left,
              width: `${d.size}px`,
              height: `${Math.round(d.size * 1.5)}px`,
              animation: `stain-fall ${d.dur} cubic-bezier(0.55,0.05,0.7,0.45) ${d.delay} infinite`,
              filter: 'drop-shadow(0 1px 2px rgba(107,66,32,0.35))',
              transform: 'translateX(-50%)',
            }}
            viewBox="0 0 24 36"
          >
            <defs>
              <linearGradient id={`stain-${i}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#D08A4E" />
                <stop offset="50%" stopColor="#A0602C" />
                <stop offset="100%" stopColor="#5E3A1B" />
              </linearGradient>
            </defs>
            <path d="M12 2 C 9 9, 4 17, 4 24 a 8 8 0 0 0 16 0 C 20 17, 15 9, 12 2 Z" fill={`url(#stain-${i})`} />
            <ellipse cx="9" cy="22" rx="2" ry="3.5" fill="white" fillOpacity="0.4" />
          </svg>
        ))}
      </div>

      {/* Wood plank surface with grain */}
      <svg className="absolute bottom-7 left-3 right-3 h-5" viewBox="0 0 200 20" preserveAspectRatio="none">
        <rect x="0" y="4" width="200" height="14" rx="2" fill="#8B5A2B" fillOpacity="0.28" />
        <path d="M 0,8 Q 30,6 60,8 T 120,8 T 200,7" fill="none" stroke="#6B4220" strokeOpacity="0.45" strokeWidth="0.7" />
        <path d="M 0,12 Q 40,14 80,12 T 160,12 T 200,13" fill="none" stroke="#6B4220" strokeOpacity="0.35" strokeWidth="0.6" />
        <path d="M 0,15.5 Q 50,14 100,15.5 T 200,15" fill="none" stroke="#6B4220" strokeOpacity="0.25" strokeWidth="0.5" />
        <ellipse cx="132" cy="11" rx="5" ry="2.2" fill="none" stroke="#6B4220" strokeOpacity="0.4" strokeWidth="0.6" />
      </svg>

      {/* Soak-in rings */}
      <div className="absolute bottom-[40px] left-3 right-3 h-2">
        {soaks.map((r, i) => (
          <span
            key={i}
            className="absolute top-0 -translate-x-1/2 rounded-full bg-primary-dark/30"
            style={{ left: r.left, width: '5px', height: '3px', animation: `stain-soak 2.4s ease-out ${r.delay} infinite` }}
          />
        ))}
      </div>

      {/* Status */}
      <div className="absolute bottom-2 left-4 right-4 flex items-center justify-between z-20">
        <div className="flex items-center gap-2 min-w-0">
          <span className={`relative h-2 w-2 rounded-full ${toneDot}`}>
            {status.tone === 'accent' && <span className={`absolute inset-0 rounded-full ${toneDot} animate-ping`} />}
          </span>
          <span key={status.text} className={`font-mono text-[10px] truncate ${toneText}`} style={{ animation: 'stain-fadein 0.35s ease-out' }}>
            {status.text}
          </span>
        </div>
        <span className={`font-mono text-[9px] uppercase tracking-[0.2em] whitespace-nowrap pl-2 ${toneText}`}>{status.label}</span>
      </div>

      <style>{`
        @keyframes stain-fall {
          0%   { transform: translate(-50%, -10px); opacity: 0; }
          12%  { opacity: 1; }
          82%  { opacity: 1; }
          100% { transform: translate(-50%, 92px); opacity: 0; }
        }
        @keyframes stain-soak {
          0%   { transform: translateX(-50%) scale(0.4, 0.6); opacity: 0.9; }
          80%  { transform: translateX(-50%) scale(5, 1.4); opacity: 0; }
          100% { transform: translateX(-50%) scale(5, 1.4); opacity: 0; }
        }
        @keyframes stain-fadein {
          from { opacity: 0; transform: translateY(2px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

/* ----------------------------------------------------------------
   3c. Season scheduler (cursor books a staining window)
---------------------------------------------------------------- */
function SeasonScheduler() {
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S']
  const [step, setStep] = useState(0)
  const activeDay = 2

  useEffect(() => {
    const interval = setInterval(() => setStep((p) => (p + 1) % 5), 1400)
    return () => clearInterval(interval)
  }, [])

  const cursorPos = (() => {
    switch (step) {
      case 1: return { x: 60, y: 60, opacity: 1 }
      case 2:
      case 3: return { x: 30 + activeDay * 40, y: 58, opacity: 1 }
      case 4: return { x: 130, y: 130, opacity: 1 }
      default: return { x: 8, y: 110, opacity: 0 }
    }
  })()

  return (
    <div className="relative h-44 w-full bg-surface border border-divider rounded-3xl p-5 overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted">Wk 23 · June window</span>
        <span className="font-mono text-[10px] uppercase tracking-widest text-primary-dark bg-primary/10 px-2 py-0.5 rounded-full">
          Dry · 68°
        </span>
      </div>
      <div className="grid grid-cols-7 gap-2 mb-4">
        {days.map((d, idx) => (
          <div
            key={idx}
            className={`flex flex-col items-center justify-center h-9 rounded-xl text-xs font-medium transition-all duration-300 ${
              step >= 3 && idx === activeDay ? 'bg-primary text-white scale-110 shadow-lg shadow-primary/30' : 'bg-background text-ink'
            }`}
          >
            <span className={`font-mono text-[9px] ${step >= 3 && idx === activeDay ? 'text-white/70' : 'text-muted'}`}>{d}</span>
            <span className="font-display font-semibold text-sm">{idx + 8}</span>
          </div>
        ))}
      </div>
      <button
        tabIndex={-1}
        aria-hidden="true"
        className={`w-full py-2.5 rounded-2xl font-medium text-xs transition-all duration-300 ${
          step === 4 ? 'bg-accent text-white scale-[1.02] shadow-md shadow-accent/30' : 'bg-divider/50 text-muted'
        }`}
      >
        {step >= 3 ? '✓ Staining crew booked' : 'Pick a dry-weather day'}
      </button>
      <div
        className="absolute pointer-events-none transition-all duration-500 ease-out"
        style={{
          left: `${cursorPos.x}px`,
          top: `${cursorPos.y}px`,
          opacity: cursorPos.opacity,
          transform: step === 3 ? 'scale(0.85)' : 'scale(1)',
        }}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M5 3L19 12L12 13L9 20L5 3Z" fill="#1C1714" stroke="white" strokeWidth="1.5" strokeLinejoin="round" />
        </svg>
      </div>
    </div>
  )
}

/* ----------------------------------------------------------------
   3. Features
---------------------------------------------------------------- */
export function Features() {
  const sectionRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.feature-card', {
        scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', once: true },
        y: 40,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: 'power3.out',
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  const cards = [
    {
      eyebrow: '01 · Assess',
      title: 'Every face of the cabin, graded.',
      comp: <ConditionShuffler />,
      text: 'South and west walls fail first at elevation. We look at every side and tell you exactly what needs prep, how many coats, and why.',
      bullets: ['Free estimate first', 'Firm quote once you approve', 'No surprises on the invoice'],
    },
    {
      eyebrow: '02 · Re-stain',
      title: 'Stain that soaks in, not sits on top.',
      comp: <StainDrip />,
      text: 'Stain only lasts as long as the prep under it. We power wash, sand, or sand blast down to sound wood, then lay on two to three full coats.',
      bullets: ['Power wash, sand, or sand blast', '2 coats minimum, 3 when needed', 'Sprayed or hand-rolled'],
    },
    {
      eyebrow: '03 · Schedule',
      title: 'Booked around mountain weather.',
      comp: <SeasonScheduler />,
      text: 'Staining season up high runs about 16 weeks, and we only take on as many cabins as we can do right. Get on the calendar early.',
      bullets: ['Week-long & half-week jobs', 'Scheduled around mountain weather', 'Limited spots each summer'],
    },
  ]

  return (
    <section id="intro" ref={sectionRef} className="relative py-24 sm:py-32 grain-bg">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="max-w-3xl mb-14 sm:mb-20">
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ What we do</span>
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl text-ink mt-4 leading-[1.05] tracking-tighter">
            Cabin upkeep,
            <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">done before it's damage.</span>
          </h2>
          <p className="mt-6 text-muted text-base sm:text-lg leading-relaxed max-w-2xl">
            Re-staining on schedule costs a fraction of replacing rotted logs, checked siding, or a failed deck.
            That's the whole job: keep your wood protected, so your cabin stays the place you want to be.
          </p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {cards.map((c) => (
            <article key={c.eyebrow} className="feature-card rounded-3xl bg-surface border border-divider p-6 sm:p-8 flex flex-col shadow-sm">
              <span className="font-mono text-[10px] sm:text-xs uppercase tracking-[0.18em] text-muted">{c.eyebrow}</span>
              <h3 className="mt-3 font-display font-bold text-xl sm:text-2xl text-ink leading-tight tracking-tight min-h-[3.5rem]">{c.title}</h3>
              <div className="mt-6 mb-6">{c.comp}</div>
              <p className="text-muted text-sm sm:text-base leading-relaxed">{c.text}</p>
              <ul className="mt-5 space-y-2 pt-5 border-t border-divider">
                {c.bullets.map((b) => (
                  <li key={b} className="flex items-center gap-2.5 text-sm text-ink/80">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {b}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   CountUp
---------------------------------------------------------------- */
function CountUp({ end, suffix = '', prefix = '', duration = 2000, format = false }) {
  const [value, setValue] = useState(0)
  const ref = useRef(null)
  const started = useRef(false)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true
          const startTs = performance.now()
          const tick = (now) => {
            const t = Math.min(1, (now - startTs) / duration)
            const eased = 1 - Math.pow(1 - t, 3)
            setValue(Math.round(end * eased))
            if (t < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
        }
      },
      { threshold: 0.4 }
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [end, duration])

  return (
    <span ref={ref} className="tabular-nums">
      {prefix}
      {format ? value.toLocaleString('en-US') : value}
      {suffix}
    </span>
  )
}

/* ----------------------------------------------------------------
   4. Pillars — why re-staining matters up high
---------------------------------------------------------------- */
export function Pillars() {
  const pillars = [
    {
      label: 'Service radius',
      end: 100,
      suffix: ' mi',
      text: 'Duck Creek, Brian Head, Elk Ridge, Eagle Point, and anywhere else within 100 miles of Cedar City with a wood cabin that needs it.',
    },
    {
      label: 'Coats of stain',
      end: 3,
      prefix: '2–',
      text: 'Two coats is our bare minimum on every job. Weathered wood gets a third, so the finish actually lasts through the winters.',
    },
    {
      label: 'Staining season',
      end: 16,
      suffix: ' wks',
      text: 'The mountain season is short, and we cap how many cabins we take so every one gets our full attention. Spots go early.',
    },
  ]

  return (
    <section id="why" className="relative py-24 sm:py-32 overflow-hidden bg-surface">
      <div className="absolute -top-24 -left-24 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
      <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="relative max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="max-w-3xl mb-16">
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ Why re-stain</span>
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl text-ink mt-4 leading-[1.05] tracking-tighter">
            Mountain wood ages
            <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">in dog years.</span>
          </h2>
        </div>
        <div className="grid lg:grid-cols-3 lg:divide-x divide-divider border-y border-divider">
          {pillars.map((p, i) => (
            <div key={p.label} className={`py-10 lg:py-14 ${i > 0 ? 'border-t lg:border-t-0 border-divider' : ''} lg:px-10 first:lg:pl-0 last:lg:pr-0`}>
              <span className="font-mono text-[10px] sm:text-xs uppercase tracking-[0.2em] text-muted">{p.label}</span>
              <div className="mt-4 font-display font-extrabold text-6xl sm:text-7xl tracking-tighter gradient-text leading-none pb-2">
                <CountUp end={p.end} suffix={p.suffix} prefix={p.prefix} format={p.format} />
              </div>
              <div className="relative mt-5 h-px w-full bg-divider overflow-hidden">
                <span
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-accent to-transparent"
                  style={{ animation: `pillar-sweep 3s ease-in-out ${i * 0.4}s infinite` }}
                />
              </div>
              <p className="mt-5 text-muted leading-relaxed text-sm sm:text-base max-w-sm">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   5. Protocol — sticky stack
---------------------------------------------------------------- */
export function Protocol({ showHeading = true }) {
  const containerRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray('.protocol-card')
      cards.forEach((card, i) => {
        if (i === cards.length - 1) return
        gsap.to(card, {
          scrollTrigger: {
            trigger: card,
            start: 'top top+=100',
            endTrigger: cards[cards.length - 1],
            end: 'top top+=120',
            scrub: 1,
          },
          scale: 0.92,
          filter: 'blur(6px) saturate(0.7)',
          opacity: 0.5,
          ease: 'none',
        })
      })
    }, containerRef)
    return () => ctx.revert()
  }, [])

  const steps = [
    {
      num: '01',
      title: 'Estimate & quote',
      tagline: 'Know the number first.',
      text: 'We look over the cabin and send you an estimate. Once you sign off on it, you get a firm quote. Then we order materials from our supplier here in town and get you on the calendar.',
      image: IMG.step1,
      alt: 'Log cabin surrounded by forest',
      meta: 'Step 1 / Quote',
    },
    {
      num: '02',
      title: 'Surface prep',
      tagline: 'Down to sound wood.',
      text: 'Every surface gets what it needs. Some just need a power wash, some need sanding, and badly weathered logs get sand blasted. Stain is only as good as the prep underneath it.',
      image: IMG.step2,
      alt: 'Wood cabin with mountain peaks behind',
      meta: 'Step 2 / Prep',
    },
    {
      num: '03',
      title: 'Mask & stain',
      tagline: 'Two coats. Three if it needs it.',
      text: 'We mask off every AC unit, window, and anything else that shouldn’t get stain. Then we spray, or hand-roll where overspray would be a problem, for two to three full coats.',
      image: IMG.step3,
      alt: 'Snow-dusted cabin reflected in a mountain lake',
      meta: 'Step 3 / Stain',
    },
    {
      num: '04',
      title: 'Unmask & walkthrough',
      tagline: 'Clean lines, clean site.',
      text: 'All the masking comes off, the site gets cleaned up, and we walk the cabin with you so you can see every wall before we head back down the mountain.',
      image: IMG.step4,
      alt: 'Cabin in a pine forest',
      meta: 'Step 4 / Finish',
    },
  ]

  return (
    <section id="process" ref={containerRef} className="relative px-4 sm:px-6 py-24 sm:py-32 bg-background">
      {showHeading && (
      <div className="max-w-7xl mx-auto mb-16 px-2 sm:px-10">
        <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ How we work</span>
        <h2 className="font-display font-extrabold text-4xl sm:text-5xl md:text-6xl text-ink mt-4 leading-[1.05] tracking-tighter max-w-3xl">
          Four steps.
          <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">One well-kept cabin.</span>
        </h2>
      </div>
      )}

      <div className="space-y-8">
        {steps.map((step) => (
          <article
            key={step.num}
            className="protocol-card sticky top-24 sm:top-28 mx-auto max-w-6xl bg-gradient-to-br from-surface to-background border border-divider rounded-4xl sm:rounded-6xl overflow-hidden shadow-2xl shadow-primary/10"
          >
            <div className="grid lg:grid-cols-5 min-h-[60vh] lg:min-h-[70vh]">
              <div className="lg:col-span-3 p-8 sm:p-12 lg:p-16 flex flex-col justify-between">
                <div className="flex items-center justify-between gap-3">
                  <span className="font-mono text-xs uppercase tracking-[0.25em] text-muted">{step.meta}</span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-primary-dark bg-primary/10 px-2.5 py-1 rounded-full whitespace-nowrap">
                    J&amp;E Method
                  </span>
                </div>
                <div className="my-10 sm:my-12">
                  <span className="font-display font-extrabold text-[6rem] sm:text-[10rem] leading-none text-primary/15 -mb-4 block">{step.num}</span>
                  <h3 className="font-display font-bold text-3xl sm:text-5xl md:text-6xl text-ink leading-[1.02] tracking-tight">{step.title}</h3>
                  <p className="font-serif italic text-primary text-2xl sm:text-3xl mt-3">{step.tagline}</p>
                </div>
                <p className="text-muted text-base sm:text-lg leading-relaxed max-w-lg">{step.text}</p>
              </div>
              <div className="lg:col-span-2 relative overflow-hidden min-h-[260px] lg:min-h-full bg-deep">
                <img src={step.image} alt={step.alt} loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-deep/60 via-transparent to-deep/15" />
                <div className="absolute top-5 left-5 flex items-center gap-2 bg-white/90 backdrop-blur-sm rounded-full pl-3 pr-4 py-1.5 shadow-lg">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                  <span className="font-mono text-[10px] uppercase tracking-widest text-ink">Step {step.num}</span>
                </div>
                <div className="absolute bottom-4 right-4 font-mono text-[10px] uppercase tracking-widest text-white/70">
                  {step.num} / J&amp;E Surface
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   6. Services grid (dark)
---------------------------------------------------------------- */
export function ServicesGrid() {
  const ref = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.svc-tile', {
        scrollTrigger: { trigger: ref.current, start: 'top 80%', once: true },
        y: 30,
        opacity: 0,
        duration: 0.7,
        stagger: 0.08,
        ease: 'power3.out',
      })
    }, ref)
    return () => ctx.revert()
  }, [])

  return (
    <section ref={ref} className="relative bg-deep text-white py-24 sm:py-32 overflow-hidden">
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-accent/40 to-transparent" />
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-14">
          <div>
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-light">╱ Full service list</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl mt-4 leading-[1.05] tracking-tighter">
              Everything wood
              <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary-light">needs to last up here.</span>
            </h2>
          </div>
          <Link to="/contact" className="magnetic-btn self-start lg:self-auto inline-flex items-center gap-2 bg-accent text-white px-6 py-3 rounded-full font-semibold shadow-lg shadow-accent/20">
            Request a quote <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10 rounded-3xl overflow-hidden border border-white/10">
          {SERVICES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="svc-tile group bg-deep p-8 sm:p-10 transition-colors duration-300 hover:bg-white/[0.04]">
              <div className="h-12 w-12 rounded-2xl bg-primary/20 border border-primary-light/20 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                <Icon className="h-6 w-6 text-primary-light" strokeWidth={2.2} />
              </div>
              <h3 className="mt-6 font-display font-bold text-xl">{title}</h3>
              <p className="mt-3 text-white/60 leading-relaxed text-sm sm:text-base">{text}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 flex items-center gap-2 text-white/50 text-sm">
          <Fence className="h-4 w-4" /> Cabins, full-time homes, decks, fences: if it’s wood and it’s weathered, just ask.
        </p>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   7. Trust signals + service area
---------------------------------------------------------------- */
export function TrustSignals({ showBadges = true, showArea = true }) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { threshold: 0.2 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  const badges = [
    { icon: Home, title: 'Owner-run', text: `Co-owners ${BRAND.owners}, the J and the E, run the business together.` },
    { icon: ClipboardCheck, title: 'Estimate, then quote', text: 'You see an estimate first, then a firm quote once you approve it, all before any work starts.' },
    { icon: ShieldCheck, title: 'Licensed & insured', text: 'Fully licensed and insured, so your cabin is protected while we work on it.' },
  ]

  return (
    <section id="area" ref={ref} className="relative py-24 sm:py-32 grain-bg">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        {showBadges && (
        <div className="grid lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {badges.map(({ icon: Icon, title, text }, i) => (
            <div
              key={title}
              className="rounded-2xl bg-surface border border-divider p-7 shadow-sm hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10 transition-all duration-500"
              style={{
                opacity: visible ? 1 : 0,
                transform: visible ? 'translateY(0)' : 'translateY(24px)',
                transitionDelay: `${i * 120}ms`,
              }}
            >
              <div className="h-11 w-11 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Icon className="h-5 w-5 text-primary-dark" strokeWidth={2.2} />
              </div>
              <h3 className="mt-5 font-display font-bold text-lg text-ink">{title}</h3>
              <p className="mt-2 text-muted text-sm leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
        )}

        {/* Service area */}
        {showArea && (
        <div className={`${showBadges ? 'mt-16 sm:mt-24' : ''} relative rounded-4xl sm:rounded-6xl overflow-hidden bg-deep`}>
          <img src={IMG.area} alt="Cabin in a pine forest" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-r from-deep via-deep/70 to-transparent" />
          <div className="relative p-8 sm:p-14 lg:p-20 max-w-3xl">
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-light">╱ Service area</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mt-4 leading-[1.05] tracking-tighter">
              Anywhere within
              <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary-light">100 miles of Cedar City.</span>
            </h2>
            <p className="mt-5 text-white/70 leading-relaxed max-w-xl">
              Our home turf is Duck Creek, Brian Head, Elk Ridge, and Eagle Point, but if you have a wood cabin or home within 100 miles of
              Cedar City that needs re-staining, we'll make the drive.
            </p>
            <ul className="mt-8 flex flex-wrap gap-2">
              {SERVICE_AREAS.map((a) => (
                <li key={a} className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 backdrop-blur-sm px-3.5 py-1.5 text-sm text-white/85">
                  <MapPin className="h-3.5 w-3.5 text-accent" /> {a}
                </li>
              ))}
            </ul>
          </div>
        </div>
        )}
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   8. Contact form
---------------------------------------------------------------- */
function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block font-mono text-[10px] uppercase tracking-[0.18em] text-muted mb-2">{label}</span>
      {children}
    </label>
  )
}

const inputCls =
  'w-full rounded-2xl border border-divider bg-background px-4 py-3 text-ink placeholder:text-muted/60 outline-none transition focus:border-primary focus:ring-4 focus:ring-primary/15'

export function ContactForm() {
  const [status, setStatus] = useState('idle')
  const [files, setFiles] = useState([])
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef(null)

  const addFiles = (list) => {
    const imgs = [...list].filter((f) => f.type.startsWith('image/'))
    setFiles((prev) => [...prev, ...imgs].slice(0, 5))
  }

  const onSubmit = (e) => {
    e.preventDefault()
    setStatus('sending')
    setTimeout(() => setStatus('sent'), 1200)
  }

  const contacts = [
    { icon: Phone, label: 'Call or text', value: BRAND.phoneDisplay, href: `tel:${BRAND.phoneTel}` },
    { icon: Mail, label: 'Email', value: BRAND.email, href: `mailto:${BRAND.email}` },
    { icon: MapPin, label: 'Based in', value: `${BRAND.base} · ${BRAND.hours}` },
  ]

  return (
    <section id="contact" className="relative py-24 sm:py-32 bg-surface">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-5">
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ Free estimate</span>
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-ink mt-4 leading-[1.05] tracking-tighter">
            Let's look at
            <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">your cabin.</span>
          </h2>
          <p className="mt-6 text-muted leading-relaxed">
            Tell us where the cabin is and send a few photos of the sunniest walls and the deck. We'll reply with next
            steps and a time to come take a look.
          </p>
          <div className="mt-10 space-y-3">
            {contacts.map(({ icon: Icon, label, value, href }) => {
              const Tag = href ? 'a' : 'div'
              return (
                <Tag
                  key={label}
                  {...(href ? { href } : {})}
                  className="flex items-center gap-4 rounded-2xl border border-divider bg-background p-4 transition hover:border-primary/40"
                >
                  <span className="h-11 w-11 shrink-0 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Icon className="h-5 w-5 text-primary-dark" strokeWidth={2.2} />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-mono text-[10px] uppercase tracking-[0.18em] text-muted">{label}</span>
                    <span className="block font-medium text-ink truncate">{value}</span>
                  </span>
                </Tag>
              )
            })}
          </div>
          <p className="mt-8 flex items-start gap-2 text-xs text-muted leading-relaxed">
            <Lock className="h-3.5 w-3.5 mt-0.5 shrink-0" /> Your info and photos are only used to quote your project.
            Never shared, never sold.
          </p>
        </div>

        <div className="lg:col-span-7">
          <div className="rounded-3xl border border-divider bg-background/60 p-6 sm:p-10 shadow-xl shadow-primary/5">
            {status === 'sent' ? (
              <div className="py-16 text-center">
                <CheckCircle2 className="h-14 w-14 text-accent mx-auto" strokeWidth={1.8} />
                <h3 className="mt-6 font-display font-bold text-2xl text-ink">Thanks, we got it.</h3>
                <p className="mt-2 text-muted">We'll be in touch within one business day.</p>
                <button
                  onClick={() => { setStatus('idle'); setFiles([]) }}
                  className="mt-8 text-sm font-medium text-primary-dark underline underline-offset-4"
                >
                  Send another request
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                  <Field label="Name"><input required name="name" autoComplete="name" className={inputCls} placeholder="Your name" /></Field>
                  <Field label="Email"><input required type="email" name="email" autoComplete="email" className={inputCls} placeholder="you@email.com" /></Field>
                </div>
                <div className="grid sm:grid-cols-2 gap-5">
                  <Field label="Phone"><input type="tel" name="phone" autoComplete="tel" className={inputCls} placeholder="(435) 000-0000" /></Field>
                  <Field label="Cabin location">
                    <select name="location" className={inputCls} defaultValue="">
                      <option value="" disabled>Choose an area</option>
                      {SERVICE_AREAS.map((a) => <option key={a}>{a}</option>)}
                      <option>Other / not sure</option>
                    </select>
                  </Field>
                </div>
                <Field label="What needs attention?">
                  <textarea name="message" rows={5} className={`${inputCls} resize-none`} placeholder="e.g. Log cabin, last stained ~4 years ago, south wall is going grey, deck is peeling…" />
                </Field>

                <div
                  onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={(e) => { e.preventDefault(); setDragging(false); addFiles(e.dataTransfer.files) }}
                  onClick={() => fileRef.current?.click()}
                  className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 text-center transition ${
                    dragging ? 'border-accent bg-accent/5' : 'border-divider hover:border-primary/40'
                  }`}
                >
                  <Upload className="h-6 w-6 text-primary mx-auto" />
                  <p className="mt-2 text-sm text-ink font-medium">Drop cabin photos here or click to upload</p>
                  <p className="text-xs text-muted mt-1">Up to 5 images · sunny walls, deck, close-ups of worn spots</p>
                  <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => addFiles(e.target.files)} />
                </div>
                {files.length > 0 && (
                  <ul className="space-y-2">
                    {files.map((f, i) => (
                      <li key={i} className="flex items-center justify-between rounded-xl bg-surface border border-divider px-4 py-2 text-sm">
                        <span className="truncate text-ink">{f.name}</span>
                        <button type="button" onClick={() => setFiles((p) => p.filter((_, j) => j !== i))} className="text-muted hover:text-accent" aria-label={`Remove ${f.name}`}>
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}

                <button
                  type="submit"
                  disabled={status === 'sending'}
                  className="magnetic-btn w-full inline-flex items-center justify-center gap-2 bg-accent text-white px-6 py-4 rounded-full font-semibold shadow-lg shadow-accent/30 disabled:opacity-70"
                >
                  {status === 'sending' ? 'Sending…' : <>Request my free estimate <ArrowUpRight className="h-4 w-4" /></>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   9. Footer
---------------------------------------------------------------- */
export function Footer() {
  return (
    <footer className="relative bg-deep text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="grid gap-12 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <LogoMark light />
            <p className="mt-6 font-serif italic text-2xl text-white/80 max-w-sm leading-snug">
              Keeping Southern Utah's mountain cabins protected, one coat at a time.
            </p>
            <div className="mt-8 inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2">
              <span className="h-2 w-2 rounded-full bg-accent ring-pulse" />
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/70">Now booking next staining season</span>
            </div>
          </div>
          <div>
            <h4 className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/40">Services</h4>
            <ul className="mt-5 space-y-3 text-sm text-white/70">
              {SERVICES.slice(0, 5).map((s) => (
                <li key={s.title}><Link to="/services" className="hover:text-white transition">{s.title}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/40">Company</h4>
            <ul className="mt-5 space-y-3 text-sm text-white/70">
              {NAV_LINKS.map((l) => (
                <li key={l.to}><Link to={l.to} className="hover:text-white transition">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/40">Contact</h4>
            <ul className="mt-5 space-y-3 text-sm text-white/70">
              <li><a href={`tel:${BRAND.phoneTel}`} className="hover:text-white transition">{BRAND.phoneDisplay}</a></li>
              <li><a href={`mailto:${BRAND.email}`} className="hover:text-white transition break-all">{BRAND.email}</a></li>
              <li>{BRAND.base}</li>
              <li>Owners: {BRAND.owners}</li>
              <li>{BRAND.hours}</li>
            </ul>
          </div>
        </div>
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-between text-xs text-white/40">
          <p>© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="/privacy" className="hover:text-white transition">Privacy</Link>
            <Link to="/terms" className="hover:text-white transition">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

/* ----------------------------------------------------------------
   Page hero — dark banner for inner pages
---------------------------------------------------------------- */
export function PageHero({ eyebrow, title, flourish, text, image }) {
  const ref = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.ph-anim', { y: 30, opacity: 0, duration: 0.9, stagger: 0.12, delay: 0.15, ease: 'power3.out' })
    }, ref)
    return () => ctx.revert()
  }, [])

  return (
    <section ref={ref} className="relative overflow-hidden bg-deep">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover brightness-[0.5]" />
      <div className="absolute inset-0 bg-gradient-to-br from-deep/90 via-deep/50 to-deep/70" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-deep/80 to-transparent" />
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-40 pb-20 sm:pt-48 sm:pb-28">
        <p className="ph-anim font-mono text-[10px] sm:text-xs uppercase tracking-[0.25em] text-primary-light">╱ {eyebrow}</p>
        <h1 className="ph-anim mt-5 font-display font-bold text-4xl sm:text-6xl lg:text-7xl text-white tracking-tighter leading-[0.98] max-w-4xl">
          {title}
          <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary-light text-balance">{flourish}</span>
        </h1>
        {text && <p className="ph-anim mt-6 max-w-xl text-white/75 text-base sm:text-lg leading-relaxed">{text}</p>}
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   Process teaser — compact 4-step strip for the home page
---------------------------------------------------------------- */
export function ProcessTeaser() {
  const steps = [
    { num: '01', title: 'Estimate & quote', text: 'Estimate first, firm quote once you sign off.' },
    { num: '02', title: 'Surface prep', text: 'Power wash, sand, or sand blast to sound wood.' },
    { num: '03', title: 'Mask & stain', text: 'Everything masked, then 2–3 sprayed or rolled coats.' },
    { num: '04', title: 'Unmask & walkthrough', text: 'Masking off, site cleaned, cabin walked with you.' },
  ]
  return (
    <section className="relative py-24 sm:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-14">
          <div>
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ How we work</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl text-ink mt-4 leading-[1.05] tracking-tighter">
              Four steps.
              <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">One well-kept cabin.</span>
            </h2>
          </div>
          <Link to="/process" className="magnetic-btn self-start lg:self-auto inline-flex items-center gap-2 border border-ink/15 bg-surface text-ink px-6 py-3 rounded-full font-semibold">
            See the full process <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
        <ol className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((st) => (
            <li key={st.num} className="rounded-3xl bg-surface border border-divider p-7 shadow-sm">
              <span className="font-display font-extrabold text-5xl text-primary/20 leading-none">{st.num}</span>
              <h3 className="mt-4 font-display font-bold text-lg text-ink">{st.title}</h3>
              <p className="mt-2 text-muted text-sm leading-relaxed">{st.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------------
   CTA band
---------------------------------------------------------------- */
export function CtaBand() {
  return (
    <section className="relative px-4 sm:px-6 pb-24 sm:pb-32 pt-4 bg-background">
      <div className="relative max-w-6xl mx-auto overflow-hidden rounded-4xl sm:rounded-6xl bg-deep px-8 py-14 sm:px-16 sm:py-20">
        <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-accent/25 blur-3xl" />
        <div className="absolute -bottom-24 -left-10 h-72 w-72 rounded-full bg-primary/30 blur-3xl" />
        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
          <div>
            <p className="font-mono text-[10px] sm:text-xs uppercase tracking-[0.25em] text-primary-light">╱ Limited spots each season</p>
            <h2 className="mt-4 font-display font-extrabold text-3xl sm:text-5xl text-white tracking-tighter leading-[1.05]">
              Get your cabin
              <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary-light">on this summer's calendar.</span>
            </h2>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link to="/contact" className="magnetic-btn inline-flex items-center gap-2 bg-accent text-white px-6 py-3.5 rounded-full font-semibold shadow-lg shadow-accent/30">
              Get a free estimate <ArrowUpRight className="h-4 w-4" />
            </Link>
            <a href={`tel:${BRAND.phoneTel}`} className="magnetic-btn inline-flex items-center gap-2 glass-dark text-white px-6 py-3.5 rounded-full font-semibold border border-white/15">
              <Phone className="h-4 w-4" /> {BRAND.phoneDisplay}
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export { IMG, BRAND }
