import { Hero, Features, Pillars, ServicesGrid, ProcessTeaser, TrustSignals, CtaBand } from '../sections.jsx'

export default function Home() {
  return (
    <>
      <Hero />
      <Features />
      <Pillars />
      <ServicesGrid />
      <ProcessTeaser />
      <TrustSignals showArea={false} />
      <CtaBand />
    </>
  )
}
