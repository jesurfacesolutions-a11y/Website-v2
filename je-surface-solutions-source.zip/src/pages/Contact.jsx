import { PageHero, ContactForm, IMG } from '../sections.jsx'

export default function Contact() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Get in touch."
        flourish="Estimates are always free."
        image={IMG.hero}
      />
      <ContactForm />
    </>
  )
}
