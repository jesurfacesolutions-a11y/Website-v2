import { PageHero, Protocol, CtaBand, IMG } from '../sections.jsx'

export default function Process() {
  return (
    <>
      <PageHero
        eyebrow="Our process"
        title="Four steps."
        flourish="One well-kept cabin."
        text="From the first estimate to the final walkthrough, here's exactly what happens when we re-stain your cabin."
        image={IMG.step1}
      />
      <Protocol showHeading={false} />
      <CtaBand />
    </>
  )
}
