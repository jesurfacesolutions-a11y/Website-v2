import { PageHero, TrustSignals, Pillars, CtaBand, IMG } from '../sections.jsx'

export default function ServiceArea() {
  return (
    <>
      <PageHero
        eyebrow="Service area"
        title="Southern Utah's"
        flourish="cabin country."
        text="Based in Cedar City and working anywhere within 100 miles: Duck Creek, Brian Head, Elk Ridge, Eagle Point, and beyond."
        image={IMG.step3}
      />
      <TrustSignals showBadges={false} />
      <Pillars />
      <CtaBand />
    </>
  )
}
