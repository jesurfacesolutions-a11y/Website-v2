import Legal from './Legal.jsx'

export default function PrivacyPolicy() {
  return (
    <Legal
      eyebrow="Legal"
      title="Privacy Policy"
      updated="September 2026"
      sections={[
        { h: 'What we collect', p: 'When you request a quote, we collect your name, email, phone number, cabin location, and any photos you choose to upload. We use this only to assess your project and get back to you.' },
        { h: 'How we use it', p: 'Your information is used to prepare estimates, schedule work, and send service reminders you have agreed to receive. We never sell or rent your information.' },
        { h: 'Photos', p: 'Photos you upload of your cabin are used to evaluate wood condition and are never published without your written permission.' },
        { h: 'Contact', p: 'Questions about your data? Reach us through the contact details listed on our homepage and we will respond promptly.' },
      ]}
    />
  )
}
