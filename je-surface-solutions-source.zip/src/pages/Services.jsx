import { PageHero, ServicesGrid, TrustSignals, CtaBand, IMG } from '../sections.jsx'

export default function Services() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title="Prep, stain, protect."
        flourish="Every wood surface, done right."
        text="From a simple re-coat to sand blasting weathered logs back to fresh wood, here's everything we do for cabins and wood homes in Southern Utah."
        image={IMG.step2}
      />
      <ServicesGrid />
      <TrustSignals showArea={false} />
      <CtaBand />
    </>
  )
}
