import Legal from './Legal.jsx'

export default function Terms() {
  return (
    <Legal
      eyebrow="Legal"
      title="Terms of Service"
      updated="September 2026"
      sections={[
        { h: 'Estimates', p: 'All quotes are provided in writing after an on-site or photo-based assessment. Estimates are valid for 30 days unless stated otherwise.' },
        { h: 'Scheduling & weather', p: 'Staining depends on temperature, moisture, and wood dryness. Mountain weather changes fast, so we may reschedule to protect the quality of the finish.' },
        { h: 'Workmanship', p: 'Workmanship terms and any warranty coverage are outlined in your written project agreement.' },
        { h: 'Payment', p: 'Payment terms, deposits, and schedules are defined in your project agreement before any work begins.' },
      ]}
    />
  )
}
