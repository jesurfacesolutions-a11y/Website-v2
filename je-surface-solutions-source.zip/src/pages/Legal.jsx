import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

export default function Legal({ eyebrow, title, updated, sections }) {
  useEffect(() => { window.scrollTo(0, 0) }, [])
  return (
    <div className="min-h-screen bg-background grain-bg">
      <div className="max-w-3xl mx-auto px-6 sm:px-10 pt-32 pb-20 sm:pt-40 sm:pb-28">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-primary-dark lift-on-hover">
          <ArrowLeft className="h-4 w-4" /> Back to home
        </Link>
        <p className="mt-12 font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">{eyebrow}</p>
        <h1 className="mt-4 font-display font-extrabold text-4xl sm:text-5xl tracking-tight text-ink">{title}</h1>
        <p className="mt-3 font-mono text-xs text-muted">Last updated {updated}</p>
        <div className="mt-12 space-y-10">
          {sections.map((s) => (
            <section key={s.h}>
              <h2 className="font-display font-bold text-xl text-ink">{s.h}</h2>
              <p className="mt-3 text-muted leading-relaxed">{s.p}</p>
            </section>
          ))}
        </div>
      </div>
    </div>
  )
}
