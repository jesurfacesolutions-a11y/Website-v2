import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { Camera, Handshake, ClipboardCheck, ShieldCheck } from 'lucide-react'
import { PageHero, CtaBand, IMG, BRAND } from '../sections.jsx'

// Swap `photo` for an image path (e.g. '/team/colton.jpg') and `bio` for real copy
const FOUNDERS = [
  { name: 'Colton Emmett', role: 'Co-Founder', letter: 'E', photo: '/team/colton.jpg', photoPos: '60% 22%', bio: null },
  { name: 'Caden Jacobs', role: 'Co-Founder', letter: 'J', photo: null, bio: null },
]

const VALUES = [
  { icon: Handshake, title: 'Owners on the job', text: 'You deal directly with the two people who own the company, from the first estimate to the final walkthrough.' },
  { icon: ClipboardCheck, title: 'Prep over shortcuts', text: 'Two coats minimum, and a third when the wood needs it. We never cut corners on prep.' },
  { icon: ShieldCheck, title: 'Licensed & insured', text: 'Fully licensed and insured, so your cabin is protected while we work on it.' },
]

function FounderCard({ name, role, letter, photo, photoPos = 'center', bio }) {
  return (
    <article className="founder-card group rounded-4xl bg-surface border border-divider overflow-hidden shadow-sm hover:shadow-xl hover:shadow-primary/10 transition-shadow duration-500">
      <div className="relative aspect-[4/5] bg-gradient-to-br from-primary-light/30 via-background to-primary/20 overflow-hidden">
        {photo ? (
          <img src={photo} alt={name} style={{ objectPosition: photoPos }} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
        ) : (
          <div className="absolute inset-4 rounded-3xl border-2 border-dashed border-primary/30 flex flex-col items-center justify-center text-center">
            <span className="font-display font-extrabold text-[9rem] leading-none text-primary/15 select-none">{letter}</span>
            <span className="mt-2 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-dark bg-surface/80 px-3 py-1.5 rounded-full">
              <Camera className="h-3.5 w-3.5" /> Photo coming soon
            </span>
          </div>
        )}
        <span className="absolute top-5 left-5 font-mono text-[10px] uppercase tracking-widest text-ink bg-white/90 rounded-full px-3 py-1.5 shadow">
          The “{letter}” in J&amp;E
        </span>
      </div>
      <div className="p-7 sm:p-9">
        <h3 className="font-display font-bold text-2xl sm:text-3xl text-ink tracking-tight">{name}</h3>
        <p className="mt-1 font-serif italic text-xl text-primary">{role}</p>
        {bio ? (
          <p className="mt-5 text-muted leading-relaxed">{bio}</p>
        ) : (
          <div className="mt-5 space-y-2.5" aria-label="Bio coming soon">
            <span className="block h-2.5 w-full rounded-full bg-divider" />
            <span className="block h-2.5 w-11/12 rounded-full bg-divider" />
            <span className="block h-2.5 w-4/6 rounded-full bg-divider" />
            <span className="block pt-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted">Bio coming soon</span>
          </div>
        )}
      </div>
    </article>
  )
}

export default function About() {
  const ref = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.founder-card', {
        scrollTrigger: { trigger: ref.current, start: 'top 80%', once: true },
        y: 40, opacity: 0, duration: 0.8, stagger: 0.15, ease: 'power3.out',
      })
    }, ref)
    return () => ctx.revert()
  }, [])

  return (
    <>
      <PageHero
        eyebrow="About us"
        title="Two founders."
        flourish="One standard for every cabin."
        text={`J&E Surface Solutions is ${BRAND.owners.replace('&', 'and')}, a Southern Utah company built to keep mountain cabins protected.`}
        image={IMG.step4}
      />

      <section ref={ref} className="relative py-24 sm:py-32 grain-bg">
        <div className="max-w-6xl mx-auto px-6 sm:px-10 lg:px-16">
          <div className="max-w-3xl mb-14 sm:mb-20">
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ Meet the founders</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl text-ink mt-4 leading-[1.05] tracking-tighter">
              The J and the E.
              <span className="block font-serif italic font-normal tracking-[-0.01em] text-primary">Jacobs &amp; Emmett.</span>
            </h2>
            <p className="mt-6 text-muted text-base sm:text-lg leading-relaxed max-w-2xl">
              Co-owners who run the business together, from knocking on doors to masking the last window.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 lg:gap-10">
            {FOUNDERS.map((f) => <FounderCard key={f.name} {...f} />)}
          </div>
        </div>
      </section>

      <section className="relative py-24 sm:py-28 bg-surface">
        <div className="max-w-6xl mx-auto px-6 sm:px-10 lg:px-16">
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-primary-dark">╱ What we stand for</span>
          <div className="mt-10 grid lg:grid-cols-3 gap-6">
            {VALUES.map(({ icon: Icon, title, text }) => (
              <div key={title} className="rounded-2xl bg-background border border-divider p-7">
                <div className="h-11 w-11 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Icon className="h-5 w-5 text-primary-dark" strokeWidth={2.2} />
                </div>
                <h3 className="mt-5 font-display font-bold text-lg text-ink">{title}</h3>
                <p className="mt-2 text-muted text-sm leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  )
}
