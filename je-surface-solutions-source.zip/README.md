# J&E Surface Solutions

Marketing site for J&E Surface Solutions: cabin and log home re-staining within 100 miles of Cedar City, Utah.

Built with React, Vite, Tailwind CSS, and GSAP.

```bash
npm install
npm run dev     # local preview at http://localhost:5173
npm run build   # production build in dist/
```

- Business details (phone, email, hours): `BRAND` in `src/sections.jsx`
- Founder photos and bios: `FOUNDERS` in `src/pages/About.jsx` (photos live in `public/team/`)
